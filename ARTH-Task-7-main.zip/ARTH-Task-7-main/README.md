# ARTH-Task-7
 WE have created a Menu using python which can automate the functionalities of technologies like AWS , Docker, Hadoop and concepts of LVM , partitioning etc.
 
 We have created the following menu which will provide the further sub-menus on pressing the keys.
 
       press 0 : To clear cache
       Press 1 : To run date
       press 2 : To cal 
       press 3 : To reboot
       press 4 : For docker functionalities
       press 5 : For Hadoop 
       press 6 : To create partition/info about disks
       press 7 : LVM
       press 8 : To configure web server
       press 9 : For AWS functionalities
       press 10 :To exit
